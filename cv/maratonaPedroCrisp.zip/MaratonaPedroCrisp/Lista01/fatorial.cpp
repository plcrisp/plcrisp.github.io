#include <bits/stdc++.h>

using namespace std;

int main() {
    int m, n;
    while (cin >> m >> n){
        unsigned long long int fat1=1, fat2=1, soma;
        for(int i=1;i<=m;i++){
            fat1 = fat1 * i;
        }
        for(int i=1;i<=n;i++){
            fat2= fat2 * i;
        }
        soma = fat1+fat2;
        cout << soma << endl;
    }
    return 0;
}

