#include <bits/stdc++.h>

using namespace std;

int main(){
    while(true){
        int n,m,aux;
        cin >> n >> m;
        if(n==0&&m==0){
            break;
        }
        int aux;
        vector<int> jogadores;
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                cin >> aux;
                jogadores.push_back(aux);
            }
        }

        for(int i=0;i<jogadores.size();i++){
            ocorrencia[i]++;
        }
    }
	return 0;
}
