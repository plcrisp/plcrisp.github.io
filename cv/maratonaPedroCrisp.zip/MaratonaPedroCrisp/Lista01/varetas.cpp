#include <bits/stdc++.h>

using namespace std;

int main(){
    while(true){
        int n;
        cin >> n;
        if(n==0){
            break;
        }
        int ci, vi;
        int lados=0,ret=0;
        for(int i=0;i<n;i++){
            cin >> ci >> vi;
            lados = lados + (vi/2);
        }
        ret = lados / 2;
        cout << ret << endl;
    }
	return 0;
}
