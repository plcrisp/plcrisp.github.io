#include <bits/stdc++.h>
#define g 9.80665
#define pi 3.14159

using namespace std;

int main(){
    double h;
    int p1, p2;
    int n;
    double ang, v;
    double alcance;
    while(cin >> h){
        cin >> p1 >> p2;
        cin >> n;
        for(int i=0;i<n;i++){
            cin >> ang >> v;
            ang = (ang * pi)/180.0;
            alcance = (v * cos(ang) / g) * (v * sin(ang) + sqrt(v * v * sin(ang) * sin(ang) + 2 * g * h));
            if((alcance>=p1)&&(alcance<=p2)){
                cout << fixed << setprecision(5) << alcance << " -> DUCK" << endl;
            }else{
                cout << fixed << setprecision(5) << alcance << " -> NUCK" << endl;
            }
        }
    }
	return 0;
}
