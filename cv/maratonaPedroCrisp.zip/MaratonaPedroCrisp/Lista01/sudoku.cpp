#include <bits/stdc++.h>
#define g 9.80665
#define pi 3.14159

using namespace std;

int main(){
    int matriz[9][9];
    int n;
    cin >> n;
    for(int k=0;k<n;k++){
        for(int i=0;i<9;i++){
            for(int j=0;j<9;j++){
                cin >> matriz[i][j];
            }
        }
        for(int i=0;i<9;i++){
            for(int j=0;j<9;j++){

            }
        }
    }
	return 0;
}
