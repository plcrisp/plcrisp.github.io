#include <bits/stdc++.h>

using namespace std;

void bubbleSort(int v[], int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (v[j] > v[j + 1]) {
                int temp = v[j];
                v[j] = v[j + 1];
                v[j + 1] = temp;
            }
        }
    }
}

int main() {
    int v[3], vaux[3];
    int aux;

    cin >> v[0] >> v[1] >> v[2];
    vaux[0] = v[0];
    vaux[1] = v[1];
    vaux[2] = v[2];

    bubbleSort(v, 3); // Ordena v

    for (int i = 0; i < 3; i++) {
        cout << v[i] << endl;
    }
    cout << endl;
    for (int i = 0; i < 3; i++) {
        cout << vaux[i] << endl;
    }

    return 0;
}
