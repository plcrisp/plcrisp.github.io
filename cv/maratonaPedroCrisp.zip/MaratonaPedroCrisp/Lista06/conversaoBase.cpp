#include <bits/stdc++.h>

using namespace std;

void conversorBin(string a){
    long long int dec;
    for(int i=0;i<a.size();i++){
        if(a[i]=='1'){
            dec+=pow(2,(a.size()-1-i));
        }
    }
    cout << dec << " dec" << endl;

    cout << hex << dec << " hex" << endl;
}

void conversorDec(string a)

int main(){
    int n;
    cin >> n;
    for(int i=0;i<n;i++){
        string num, base;
        cin >> num >> base;

    }
    return 0;
}
