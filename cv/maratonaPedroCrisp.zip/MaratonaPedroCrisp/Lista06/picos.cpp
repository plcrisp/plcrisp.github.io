#include <bits/stdc++.h>

using namespace std;

int main(){
    while(true){
        int n;
        cin >> n;
        if(n==0)break;
        vector<int> h;
        int cont=0;
        int aux;
        for(int i=0;i<n;i++){
            cin >> aux;
            h.push_back(aux);
        }
        
        for(int i=0;i<h.size();i++){
            if(i==h.size()-1){
                if(((h[i]>h[i-1])&&(h[i]>h[0]))||((h[i]<h[i-1])&&(h[i]<h[0]))) cont++;
            }else if(i==0){
                if(((h[i]>h[i+1])&&(h[i]>h[h.size()-1]))||((h[i]<h[i+1])&&(h[i]<h[h.size()-1]))) cont++;
            }else{
                if(((h[i]>h[i-1])&&(h[i]>h[i+1]))||((h[i]<h[i-1])&&(h[i]<h[i+1]))) cont++;
            }
        }

        cout << cont << endl;
        h.clear();
    }
    return 0;
}
