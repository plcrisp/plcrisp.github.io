#include <bits/stdc++.h>

using namespace std;

int main(){
    int n;
    cin >> n;
    for(int i=0;i<n;i++){
        string a, b;
        cin >> a >> b;
        if(a==b){
            cout << "empate" << endl;
        }else{
            if(a=="spock"){
                if(b=="tesoura" || b == "pedra"){
                    cout << "rajesh" << endl;
                }else{
                    cout << "sheldon" << endl;
                }
            }
            if(a=="tesoura"){
                if(b=="papel" || b == "lagarto"){
                    cout << "rajesh" << endl;
                }else{
                    cout << "sheldon" << endl;
                }
            }
            if(a=="pedra"){
                if(b=="tesoura" || b == "lagarto"){
                    cout << "rajesh" << endl;
                }else{
                    cout << "sheldon" << endl;
                }
            }
            if(a=="lagarto"){
                if(b=="papel" || b == "spock"){
                    cout << "rajesh" << endl;
                }else{
                    cout << "sheldon" << endl;
                }
            }
            if(a=="papel"){
                if(b=="spock" || b == "pedra"){
                    cout << "rajesh" << endl;
                }else{
                    cout << "sheldon" << endl;
                }
            }
        }
    }
	return 0;
}