#include <bits/stdc++.h>

using namespace std;

int main(){
    int n;
    cin >> n;
    for(int i=0;i<n;i++){
        string linha, resp;
        cin >> linha;
        for(int i=0;i<linha.size();i++){
            if(linha[i]!='.'){
                resp.push_back(linha[i]);
            }
        }
        int ver=0, contmenor=0, contmaior=0;
        for(int i=0;i<resp.size();i++){
            if(resp[i]=='<'){
                contmenor++;
                ver++;
            }
            if(resp[i]=='>' && ver>0){
                contmaior++;
                ver--;
            }
        }
        if(contmaior==contmenor){
            cout << contmaior << endl;
        }else if(contmaior > contmenor){
            cout << contmenor << endl;
        }else if(contmaior < contmenor){
            cout << contmaior << endl;
        }
        resp.clear();
    }
    return 0;
}
