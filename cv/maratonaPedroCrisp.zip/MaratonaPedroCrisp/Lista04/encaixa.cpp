#include <bits/stdc++.h>

using namespace std;

int main(){
    int n;
    cin >> n;
    for(int i=0;i<n;i++){
        int dif = 0, encaixa=0, k=0;;
        string A, B;
        cin >> A >> B;

        dif=A.size()-B.size();

        if(dif<0){
            cout << "nao encaixa" << endl;
        }else{
            for(int j=dif;j<A.size();j++){
                k=j-dif;
                if(A[j]!=B[k]){
                    cout << "nao encaixa" << endl;
                    encaixa=0;
                    break;
                }else{
                    encaixa=1;
                }
            }
        }

        if(encaixa==1){
            cout << "encaixa" << endl;
        }

        
    }


    return 0;
}