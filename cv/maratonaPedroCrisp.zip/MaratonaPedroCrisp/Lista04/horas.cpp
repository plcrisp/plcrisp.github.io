#include <bits/stdc++.h>

using namespace std;

int main() {
    int h, m, hora, minuto;
    while(cin >> h >> m){
        hora=h/30;
        minuto = m/6;
        if(hora==12){
            hora=00;
        }
        if(minuto==60){
            minuto=00;
        }

        if(hora<10&&minuto<10){
            cout << "0" << hora << ":" << "0" << minuto << endl;
        }else if(hora<10){
            cout << "0" << hora << ":" << minuto << endl;
        }else if(minuto<10){
            cout << hora << ":" << "0" << minuto << endl;
        }else{
            cout << hora << ":" << minuto << endl;
        }


    }

    return 0;
}