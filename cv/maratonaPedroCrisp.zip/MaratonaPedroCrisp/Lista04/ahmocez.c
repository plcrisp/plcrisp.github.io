#include <stdio.h>
#include <string.h>

int main(){
    int i=1;
    while(1){
        char ass[1000001];
        char n[300001];
        char *p;
        scanf("%s", ass);
        if(ass[0]=='0') break;
        scanf("%s", n);
        p= strstr(n,ass);
        if(i>1) printf ("\n");
        if(p){
            printf("Instancia %d\n",i);
            printf("verdadeira\n");
        }else{
            printf("Instancia %d\n",i);
            printf("falsa\n");
        }
        i++;
    }
}