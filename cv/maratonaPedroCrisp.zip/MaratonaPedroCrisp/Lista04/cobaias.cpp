#include <bits/stdc++.h>

using namespace std;

int main(){
    int n;
    cin >> n;


    char tipo;
    int x; 
    double total=0;


    vector<double> quant;
    vector<double> p;

    for(int i=0;i<3;i++){
        quant.push_back(0);
        p.push_back(0);
    }


    for(int i=0;i<n;i++){
        cin >> x >> tipo;
        total+=x;

        if(tipo=='C'){
            quant[0]+=x;
        }else if(tipo=='R'){
            quant[1]+=x;
        }else{
            quant[2]+=x;
        }
    }

    cout << "Total: " << total << " cobaias" << endl;
    cout << "Total de coelhos: " << quant[0] << endl;
    cout << "Total de ratos: " << quant[1] << endl;
    cout << "Total de sapos: " << quant[2] << endl;

    p[0]= (quant[0]/total)*100;
    p[1]= (quant[1]/total)*100;
    p[2]= (quant[2]/total)*100;

    cout << "Percentual de coelhos: " << fixed << setprecision(2) << p[0] << " %" << endl;
    cout << "Percentual de ratos: " << fixed << setprecision(2) << p[1] << " %" << endl;
    cout << "Percentual de sapos: " << fixed << setprecision(2) << p[2] << " %" << endl;
    

    return 0;
}