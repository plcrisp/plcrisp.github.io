#include <bits/stdc++.h>

using namespace std;

int main(){
    int n, g, x;
    int aux2, dano=0;
    char aux1;
    vector<char> jogadas;

    map<char,int> runas;

    cin >> n >> g;
    for(int i=0;i<n;i++){
        cin >> aux1 >> aux2;
        runas.insert(make_pair(aux1,aux2));
    }

    cin >> x;

    for(int i=0;i<x;i++){
        cin >> aux1;
        jogadas.push_back(aux1);
    }

    for(int i=0;i<jogadas.size();i++){
        dano+=runas[jogadas[i]];
    }

    cout << dano << endl;

    if(dano<g){
        cout << "My precioooous" << endl;
    }else{
        cout << "You shall pass!" << endl;
    }

    return 0;
}