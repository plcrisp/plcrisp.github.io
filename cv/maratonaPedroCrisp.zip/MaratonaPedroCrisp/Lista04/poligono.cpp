#include <bits/stdc++.h>

using namespace std;

int main(){
    long long int lados, c;

    long long int perimetro;

    cin >> lados >> c;

    perimetro = lados * c;

    cout << perimetro << endl;

    return 0;
}