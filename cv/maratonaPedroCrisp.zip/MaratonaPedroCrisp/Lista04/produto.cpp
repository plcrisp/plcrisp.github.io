#include <bits/stdc++.h>

using namespace std;

struct segment_tree {
    segment_tree* left;
    segment_tree* right;
    int from, to;
    int value;
    segment_tree(int _from, int _to) : from(_from), to(_to), left(nullptr), right(nullptr), value(1) {}
};

segment_tree* build(const vector<int>& arr, int l, int r) {
    if (l > r) return nullptr;
    segment_tree* res = new segment_tree(l, r);
    if (l == r) {
        res->value = arr[l];
    } else {
        int m = (l + r) / 2;
        res->left = build(arr, l, m);
        res->right = build(arr, m + 1, r);
        res->value = res->left->value * res->right->value;
    }
    return res;
}

int query(segment_tree* tree, int l, int r) {
    if (!tree) return 1;
    if (l <= tree->from && tree->to <= r) return tree->value;
    if (tree->to < l) return 1;
    if (r < tree->from) return 1;
    int left_result = query(tree->left, l, r);
    int right_result = query(tree->right, l, r);
    return left_result * right_result;
}

int update(segment_tree* tree, int i, int val) {
    if (!tree) return 1;
    if (tree->to < i || tree->from > i) return tree->value;
    if (tree->from == tree->to && tree->from == i) tree->value = val;
    else {
        tree->left->value = update(tree->left, i, val);
        tree->right->value = update(tree->right, i, val);
        tree->value = tree->left->value * tree->right->value;
    }
    return tree->value;
}

int main() {
    int n, k, aux, com1, com2, produto;
    vector<int> seq;
    char op;
    int primeiro = 1;

    while (cin >> n >> k) {
        segment_tree* x = nullptr;

        for (int i = 0; i < n; i++) {
            cin >> aux;
            seq.push_back(aux);
        }

        if (primeiro == 0) {
            cout << endl;
        }
        primeiro = 0;

        x = build(seq, 0, n - 1);

        for (int i = 0; i < k; i++) {
            cin >> op >> com1 >> com2;

            if (op == 'C') {
                update(x, com1 - 1, com2);
            }

            if (op == 'P') {
                int result = query(x, com1 - 1, com2 - 1);
                if (result > 0) {
                    cout << "+";
                } else if (result < 0) {
                    cout << "-";
                } else {
                    cout << "0";
                }
            }
        }
        seq.clear();
    }
    return 0;
}
