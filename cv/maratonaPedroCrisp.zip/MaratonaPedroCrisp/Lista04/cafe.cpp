#include <bits/stdc++.h>

using namespace std;

int main(){
    vector<int> a, tempo;
    int aux;

    for(int i=0;i<3;i++){
        cin >> aux;
        tempo.push_back(0);
        a.push_back(aux);
    }

    tempo[0]= a[1]*2 + (a[2]*4);

    tempo[1]= a[0]*2 + a[2]*2;

    tempo[2]= a[0]*4 + a[1]*2;

    sort(tempo.begin(),tempo.end());

    cout << tempo[0] << endl;

    return 0;
}