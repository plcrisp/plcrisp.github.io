#include <bits/stdc++.h>

using namespace std;

int main() {
    string ass, codigo;
    int primeiro = 1;
    int quant = 0;

    while (true) {
        cin >> ass;
        if (ass[0] == '0') {
            break;
        }

        char *resultado;

        cin >> codigo;

        quant++;

        if (primeiro != 1) {
            cout << endl;
        }
        primeiro = 0;

        cout << "Instancia " << quant << endl;

        size_t found = codigo.find(ass);

        if (found == string::npos) {
            cout << "falsa" << endl;
        } else {
            cout << "verdadeira" << endl;
        }
        ass.clear();
        codigo.clear();
    }

    return 0;
}