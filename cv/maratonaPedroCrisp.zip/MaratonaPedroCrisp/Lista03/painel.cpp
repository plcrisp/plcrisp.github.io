#include <bits/stdc++.h>

using namespace std;

int main(){
	int n;
	cin >> n;

	int brinde=0;
	string palavra,aux;
	vector<string> painel;
	char aux1;

	painel.push_back("FACE");

	for(int j=0;j<n;j++){
		for(int i=0;i<4;i++){
			cin >> aux1;
			palavra.push_back(aux1);
		}
		painel.push_back(palavra);
		palavra.clear();
	}

	cout << endl;

	for(int i=0;i<painel.size();i++){
		cout << painel[i] << "\t";
	}

	for(int i=1;i<n+1;i++){
		aux = painel[i];
		reverse(aux.begin(),aux.end());
		if(painel[i-1]==aux){
			brinde++;
			if(i==1){
				painel.erase(painel.begin()+i);
				i--;
				n--;
			}else{
				painel.erase(painel.begin()+i-1);
				painel.erase(painel.begin()+i-1);
				i-=2;
				n-=2;
			}
		}
		cout << endl;
		for(int i=0;i<painel.size();i++){
			cout << painel[i] << "\t";
		}
	}

	cout << endl;

	cout << brinde << endl;

	return 0;
}
