#include <bits/stdc++.h>

using namespace std;

int main(){
    while(true){
        int n;
        cin >> n;

        if(n==0){
            break;
        }

        vector<int> pilha, sobrando;

        for(int i=0;i<n;i++){
            pilha.push_back(i+1);
        }

        while(pilha.size()!=1){
            sobrando.push_back(pilha[0]);
            pilha.erase(pilha.begin());
            pilha.push_back(pilha[0]);
            pilha.erase(pilha.begin());
        }

        cout << "Discarded cards: ";

        for(int i=0;i<sobrando.size()-1;i++){
            cout << sobrando[i] << ", ";
        }
        cout << sobrando[sobrando.size()-1] << endl;

        cout << "Remaining card: " << pilha[0] << endl;

        sobrando.clear();
        pilha.clear();

    }
	return 0;
}