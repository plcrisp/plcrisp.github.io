#include <bits/stdc++.h>

using namespace std;

int main(){
	while(true){
        int n;
        cin >> n;

        vector<int> gabarito;
        char gab[6]={'A','B','C','D','E','*'};
        int indice,num=0,aux;

        if(n==0){
            break;
        }
        for(int i=0;i<n;i++){
            for(int j=0;j<5;j++){
                cin >> aux;
                if(aux<=127){
                    indice=j;
                    num++;
                }
            }

            if(num!=1){
            cout << gab[5] << endl;
            }else{
                cout << gab[indice] << endl;
            }

            num=0;
        }

    }	
	return 0;
}
