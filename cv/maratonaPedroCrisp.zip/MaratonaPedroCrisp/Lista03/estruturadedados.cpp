#include <bits/stdc++.h>

using namespace std;

int main(){
    int n;
    queue<int> q;
    priority_queue<int> pq;
    stack<int> s;

    

	while(cin >> n){
        bool fila=true, filade=true, pilha=true;
        
        int tipo, num;

        for(int i=0;i<n;i++){
            cin >> tipo >> num;
            if(tipo==1){
                q.push(num);
                pq.push(num);
                s.push(num);
            }else{
                if(s.top()==num){
                    s.pop();
                }else{
                    pilha=false;
                }

                if(pq.top()==num){
                    pq.pop();
                }else{
                    filade=false;
                }

                if(q.front()==num){
                    q.pop();
                }else{
                    fila=false;
                }
            }
        }

        if((pilha && filade)||(fila && filade)||(pilha && fila)){
            cout << "not sure" << endl;
        }else if(fila){
            cout << "queue" << endl;
        }else if(pilha){
            cout << "stack" << endl;
        }else if(filade){
            cout << "priority queue" << endl;
        }else{
            cout << "impossible" << endl;
        }

        while (!s.empty()) {
            s.pop();
        }
        while (!q.empty()) {
            q.pop();
        }
        while (!pq.empty()) {
            pq.pop();
        }
    }
	return 0;
}
