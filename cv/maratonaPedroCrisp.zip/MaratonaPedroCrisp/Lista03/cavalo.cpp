#include <bits/stdc++.h>

using namespace std;

int main(){
    int k=0;
    while(true){
        string c, p;
        int movimentos;

        cin >> c;
        if(c=="0") break;

        struct posicao{
            int x;
            int y;
        };

        posicao aux;
        aux.x=0;
        aux.y=0;

        posicao cavalo, peao;

        cavalo.y = (c[0] - '0');
        cavalo.x = (c[1] - 'a')+1; 


        int dx[8] = {1, 2, 2, 1, -1, -2, -2, -1};
        int dy[8] = {2, 1, -1, -2, -2, -1, 1, 2};


        int dxp[2]={-1,1};
        int dyp[2]={-1,-1};

        vector<posicao> posicoespeoes;
        vector<posicao> posicoescavalo;

        for(int i=0;i<8;i++){
            aux.x = cavalo.x + dx[i];
            aux.y = cavalo.y + dy[i];
            if(((aux.x>0)&&(aux.x<=8))&&((aux.y>0)&&(aux.y<=8))){
                posicoescavalo.push_back(aux);
            }
            aux.x=0;
            aux.y=0;
        }

        for(int i=0;i<8;i++){
            cin >> p;

            peao.y = p[0] - '0';
            peao.x = (p[1] - 'a')+1;

            for(int i=0;i<2;i++){
                aux.x = peao.x + dxp[i];
                aux.y = peao.y + dyp[i];
                if(((aux.x>0)&&(aux.x<=8))&&((aux.y>0)&&(aux.y<=8))){
                    posicoespeoes.push_back(aux);
                }
                aux.x=0;
                aux.y=0;
            }
        }

        movimentos=posicoescavalo.size();
        
        for(int i=0;i<posicoescavalo.size();i++){
            for(int j=0;j<posicoespeoes.size();j++){
                if((posicoescavalo[i].x==posicoespeoes[j].x)&&(posicoescavalo[i].y==posicoespeoes[j].y)){
                    movimentos--;
                    break;
                }
            }
        }
        k++;

        cout << "Caso de Teste #" << k << ": " << movimentos << " movimento(s)." << endl;

        posicoescavalo.clear();
        posicoespeoes.clear();




    }


    return 0;
}
