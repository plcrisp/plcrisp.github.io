#include <bits/stdc++.h>

using namespace std;

int main(){
	map<string,string> m;
	map<string,string>::iterator it;
	
	m.insert(make_pair("two", "dois"));
	m.insert(make_pair("dog", "cachorro"));
	m.insert(make_pair("red", "vermelho"));
	m.insert(make_pair("pen", "caneta"));
	
	cout << m["two"] << endl;
	
	cout << endl;
	
	for(it = m.begin(); it!= m.end(); it++){
		cout << (*it).first << "\t";
		cout << (*it).second << endl;
	}
	
	
	
	
	
	
	return 0;
}
