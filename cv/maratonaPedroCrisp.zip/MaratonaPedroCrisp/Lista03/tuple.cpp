#include <bits/stdc++.h>

using namespace std;

int main(){
	vector< tuple<int,int,int> > vec;
	vec.push_back( make_tuple(1,0,-2));
	vec.push_back( make_tuple(7,4,4));
	vec.push_back( make_tuple(2,2,2));
	
	vector< tuple<int,int,int>  >::iterator it;
	
	for(it = vec.begin();it != vec.end(); it++){
		cout << std::get<0>(*it) << "\t";
		cout << std::get<1>(*it) << "\t";
		cout << std::get<2>(*it) << "\t";	
		cout << endl;
	}
	return 0;
}
