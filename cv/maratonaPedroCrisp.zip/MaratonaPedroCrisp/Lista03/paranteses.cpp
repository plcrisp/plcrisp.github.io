#include <bits/stdc++.h>

using namespace std;

int main(){
	string exp;
	int cont=1010,quebrar=0;
	while(getline(cin,exp)){
		for(int i=0;i<exp.size();i++){
			if(exp[i]=='('){
				cont++;
			}
			if(exp[i]==')'){
				cont--;
				if(cont<1010){
					cout << "incorrect" << endl;
					quebrar=1;
					break;
				}
			}
			
		}
		if(quebrar==0){
			if(cont==1010){
				cout << "correct" << endl;
			}else{
				cout << "incorrect" << endl;
		}	
		}
		cont=1010;
		quebrar=0;
	} 
	return 0;
}
