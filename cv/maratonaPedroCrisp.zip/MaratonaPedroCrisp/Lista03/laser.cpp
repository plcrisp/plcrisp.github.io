#include<bits/stdc++.h>

using namespace std;

int main(){
    while(true){
        int h,c;
        cin >> h >> c;
        if(h==0&&c==0) break;

        vector<int> comprimentos, auxiliar;
        int laser;
        int aux;


        for(int i=0;i<c;i++){
            cin >> aux;
            comprimentos.push_back(aux);
        }
        laser = h-comprimentos[0];
        int anterior=comprimentos[0];

        
        for(int i=1;i<c;i++){
            if(comprimentos[i]<anterior){
                laser+=anterior-comprimentos[i];
            }
            anterior=comprimentos[i];
        }

        cout << laser << endl;
    }

    return 0;
}

