#include<bits/stdc++.h>

using namespace std;

struct camiseta{
    string nome;
    string cor;
    char tamanho;
};

bool comparaCamiseta(camiseta x, camiseta y){
    if(x.cor!=y.cor){
        return x.cor < y.cor;
    }else if(x.tamanho!=y.tamanho){
        return x.tamanho > y.tamanho;
    }else{
        return x.nome < y.nome;
    }
}



int main(){
    int primeiro=1;
    while(true){
        int n;
        cin >> n;
        if(n==0) break;

        camiseta x;
        vector<camiseta> camisetas;

        if(primeiro!=1){
            cout << endl;
        }
        primeiro=0;

        for(int i=0;i<n;i++){
            cin.ignore();
            getline(cin,x.nome);
            cin >> x.cor;
            cin >> x.tamanho;
            camisetas.push_back(x);
        }

        sort(camisetas.begin(),camisetas.end(),comparaCamiseta);

        for(int i=0;i<n;i++){
            cout << camisetas[i].cor << " " << camisetas[i].tamanho << " " << camisetas[i].nome << endl;
        }

        camisetas.clear();


    }

    return 0;
}

