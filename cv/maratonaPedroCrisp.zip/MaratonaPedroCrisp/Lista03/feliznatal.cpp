#include <bits/stdc++.h>

using namespace std;

int main(){
	map<string,string> d;
    d.insert(make_pair("brasil","Feliz Natal!"));
    d.insert(make_pair("alemanha","Frohliche Weihnachten!"));
    d.insert(make_pair("austria","Frohe Weihnacht!"));
    d.insert(make_pair("coreia","Chuk Sung Tan!"));
    d.insert(make_pair("espanha","Feliz Navidad!"));
    d.insert(make_pair("grecia","Kala Christougena!"));
    d.insert(make_pair("estados-unidos","Merry Christmas!"));
    d.insert(make_pair("inglaterra","Merry Christmas!"));
    d.insert(make_pair("australia","Merry Christmas!"));
    d.insert(make_pair("portugal","Feliz Natal!"));
    d.insert(make_pair("suecia","God Jul!"));
    d.insert(make_pair("turquia","Mutlu Noeller"));
    d.insert(make_pair("argentina","Feliz Navidad!"));
    d.insert(make_pair("chile","Feliz Navidad!"));
    d.insert(make_pair("mexico","Feliz Navidad!"));
    d.insert(make_pair("antardida","Merry Christmas!"));
    d.insert(make_pair("canada","Merry Christmas!"));
    d.insert(make_pair("irlanda","Nollaig Shona Dhuit!"));
    d.insert(make_pair("belgica","Zalig Kerstfeest!"));
    d.insert(make_pair("italia","Buon Natale!"));
    d.insert(make_pair("libia","Buon Natale!"));
    d.insert(make_pair("siria","Milad Mubarak!"));
    d.insert(make_pair("marrocos","Milad Mubarak!"));
    d.insert(make_pair("japao","Merii Kurisumasu!"));

    string entrada;

    while(cin >> entrada){
        if(d.find(entrada)==d.end()){
            cout << "--- NOT FOUND ---" << endl;
        }else{
            cout << d[entrada] << endl;
        }
    }

	return 0;
}