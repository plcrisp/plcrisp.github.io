#include <bits/stdc++.h>

using namespace std;

int main(){
	int n;
	cin >> n;
	vector<int> pares;
	vector<int> impares;
	for(int i=0;i<n;i++){
		int alunos;
		cin >> alunos;
		if(alunos % 2 == 0){
			pares.push_back(alunos);
		}else{
			impares.push_back(alunos);
		}
	}
	sort(pares.begin(),pares.end());
	sort(impares.rbegin(),impares.rend());
	for(int i=0;i<impares.size();i++){
		pares.push_back(impares[i]);
	}
	
	for(int i=0;i<pares.size();i++){
		cout << pares[i] << endl;
	}
	return 0;
}
