#include <bits/stdc++.h>

using namespace std;

int main(){
	int n;
	cin >> n;
	int alunos, cont=0;
	for(int i=0;i<n;i++){
		cin >> alunos;
		
		vector<int> notas;
		vector<int> notasAux;
		
		cont=0;
		notas.clear();
		notasAux.clear();
		int nota;
		for(int j=0;j<alunos;j++){
			cin >> nota;
			notas.push_back(nota);
			notasAux.push_back(nota);
		}
		sort(notas.rbegin(),notas.rend());
		for(int j=0;j<alunos;j++){
			if(notas[j]==notasAux[j]){
				cont++;
			}
		}
	cout << cont << endl;
	}

	return 0;
}
