#include <bits/stdc++.h>

using namespace std;

int main(){
	int n;
	cin >> n;
	for(int i=0;i<n;i++){
		int primo;
		int ifprimo=1;
		cin >> primo;
		for(int j=2;j<(primo/2);j++){
			if((primo % j)==0){
				ifprimo = 0;
				break;
			}
		}
		if(ifprimo==0){
			cout << primo << " nao eh primo" << endl;
		}else{
			cout << primo << " eh primo" << endl;
		}
	}
	return 0;
}