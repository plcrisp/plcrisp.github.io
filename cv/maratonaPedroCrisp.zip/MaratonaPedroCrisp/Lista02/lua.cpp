#include <bits/stdc++.h>

using namespace std;

int main(){
	vector<int> porcentagem;
	int aux;
	for(int i=0;i<2;i++){
		cin >> aux;
		porcentagem.push_back(aux);
	}
	if(porcentagem[1]<=2){
		cout << "nova" << endl;
	}else if(porcentagem[1]>=97){
		cout << "cheia" << endl;
	}else if(((porcentagem[0]>=3)||(porcentagem[1]>=3))&&((porcentagem[0]<=96)||(porcentagem[1]<=96))&&(porcentagem[0]<=porcentagem[1])){
		cout << "crescente" << endl;
	}else{
		cout << "minguante" << endl;
	}
	return 0;
}