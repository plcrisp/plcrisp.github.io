#include <bits/stdc++.h>

using namespace std;

int main(){
	int n, aux, resposta;
	cin >> n;
	vector<int> tiros, tirosaux;
	for(int i=0;i<n;i++){
		cin >> aux;
		tiros.push_back(aux);
		tirosaux.push_back(aux);
	}
	sort(tiros.begin(),tiros.end());
	for(int i=0;i<n;i++){
		if(tirosaux[i]==tiros[0]){
			resposta = i;
			break;
		}
	}
	cout << (resposta+1) << endl;
	return 0;
}