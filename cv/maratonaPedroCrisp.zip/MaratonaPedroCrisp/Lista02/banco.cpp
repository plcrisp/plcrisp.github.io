#include <bits/stdc++.h>

using namespace std;

int main(){
	while(true){
		int b, n, aux, aux1, aux2, aux3, y=1;
		cin >> b >> n;
		if((b==0)&&(n==0)){
			break;
		}
		vector<int> reservas;
		vector<int> devendo;
		for(int i=0;i<b;i++){
			cin >> aux;
			reservas.push_back(aux);
			devendo.push_back(0);
		}
		for(int i = 0; i < n; i++) {
    			cin >> aux1 >> aux2 >> aux3;
    			if(aux1 <= b && aux2 <= b) {
        			reservas[aux2 - 1] += aux3;
        			devendo[aux1 - 1] += aux3;
    			} else {
   			}
		}

		for(int i=0;i<b;i++){
			if(devendo[i]>reservas[i]){
				y=0;
				break;
			}
		}
		if(y==1){
			cout << "S" << endl;
		}else{
			cout << "N" << endl;
		}
	}
	return 0;
}