#include<bits/stdc++.h>
using namespace std;

int main(){
    vector<int> ocorrencia;

    for(int i=0;i<2001;i++){
        ocorrencia.push_back(0);
    }

    int n,num;
    cin >> n;

    for(int i=0;i<n;i++){
        cin >> num;
        ocorrencia[num]++;
    }

    for(int i=0;i<2001;i++){
        if(ocorrencia[i]!=0){
            cout << i << " aparece " << ocorrencia[i] << " vez(es)" << endl;
        }
    }

    return 0;
}