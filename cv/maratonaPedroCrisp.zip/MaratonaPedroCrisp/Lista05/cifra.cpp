#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;
    string cod;
    int pos;
    for(int i=0;i<n;i++){
        cin >> cod;
        cin >> pos;
        for(int j=0;j<cod.size();j++){
            cod[j]=cod[j]-pos;
            if(cod[j]<65){
                cod[j]+=26;
            }
        }
        for(int j=0;j<cod.size();j++){
            cout << cod[j];
        }
        cout << endl;
    }

    return 0;
}