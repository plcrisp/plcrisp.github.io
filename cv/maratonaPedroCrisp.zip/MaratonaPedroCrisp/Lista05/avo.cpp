#include<bits/stdc++.h>
using namespace std;

int main(){
    while(true){
        int n, m;
        cin >> n >> m;

        if(n==0 && m==0) break;

        vector<int> num;

        int aux1;

        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                cin >> aux1;
                num.push_back(aux1);
            }
        }

        map<int, int> ocorrencias;
        for (int numero : num) {
            ocorrencias[numero]++;
        }

        int primeiraMaiorOcorrencia = 0;
        for (const auto& par : ocorrencias) {
            if (par.second > primeiraMaiorOcorrencia) {
                primeiraMaiorOcorrencia = par.second;
            }
        }

        int segundaMaiorOcorrencia = 0;
        for (const auto& par : ocorrencias) {
            if (par.second < primeiraMaiorOcorrencia && par.second > segundaMaiorOcorrencia) {
                segundaMaiorOcorrencia = par.second;
            }
        }

        bool primeiroNumero=true;
        int segundo=0;

        for (const auto& par : ocorrencias) {
            if (par.second == segundaMaiorOcorrencia) {
                segundo++;
            }
        }

        for (const auto& par : ocorrencias) {
            if (par.second == segundaMaiorOcorrencia) {
                if(segundo==1){
                    cout << par.first << " " << endl;
                }else{
                    cout << par.first << " ";
                    segundo--;
                }
                primeiroNumero = false;
            }
        }
        

    }
    return 0;
}